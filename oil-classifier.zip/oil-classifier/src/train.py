"""Train + evaluate the KNN classifier and save analytics.
Run:  python -m src.train --features pixels     (or --features stats)
"""
import argparse
import json
from collections import Counter
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics import (ConfusionMatrixDisplay, accuracy_score,
                             classification_report, confusion_matrix)
from sklearn.model_selection import (GridSearchCV, StratifiedKFold,
                                     cross_val_score, train_test_split)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from .features import CLASS_NAMES, load_dataset

ROOT = Path(__file__).resolve().parent.parent


def make_pipeline(mode, k=5):
    steps = [("scale", StandardScaler())]
    if mode == "pixels":  # 12288 dims is a lot for KNN -> compress with PCA
        steps.append(("pca", PCA(n_components=0.95, svd_solver="full", random_state=42)))
    steps.append(("knn", KNeighborsClassifier(n_neighbors=k)))
    return Pipeline(steps)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(ROOT / "dataset"))
    ap.add_argument("--features", choices=["pixels", "stats"], default="pixels")
    ap.add_argument("--test-size", type=float, default=0.2)
    args = ap.parse_args()

    out_dir = ROOT / "static" / "analytics"
    out_dir.mkdir(parents=True, exist_ok=True)
    (ROOT / "models").mkdir(exist_ok=True)

    print("Extracting features ...")
    X, y, oils = load_dataset(args.data, args.features)
    print(f"{len(y)} images, feature vector length {X.shape[1]}")

    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=args.test_size, stratify=y, random_state=42)

    n_splits = int(min(5, np.bincount(y_tr).min()))
    if n_splits < 2:
        raise SystemExit("Need at least 2 training images per class.")
    cv = StratifiedKFold(n_splits, shuffle=True, random_state=42)

    grid = GridSearchCV(
        make_pipeline(args.features),
        {"knn__n_neighbors": [1, 3, 5, 7, 9, 11],
         "knn__weights": ["uniform", "distance"],
         "knn__metric": ["euclidean", "manhattan"]},
        cv=cv, n_jobs=-1)
    grid.fit(X_tr, y_tr)
    model = grid.best_estimator_
    print("Best params:", grid.best_params_, "| CV accuracy:", round(grid.best_score_, 4))

    pred = model.predict(X_te)
    acc = accuracy_score(y_te, pred)
    cm = confusion_matrix(y_te, pred, labels=[0, 1])
    report = classification_report(y_te, pred, labels=[0, 1],
                                   target_names=CLASS_NAMES, output_dict=True, zero_division=0)
    print(f"\nTest accuracy: {acc:.4f}\n")
    print(classification_report(y_te, pred, labels=[0, 1],
                                target_names=CLASS_NAMES, zero_division=0))
    print("Confusion matrix:\n", cm)

    # ---- analytics plots ----
    fig, ax = plt.subplots(figsize=(4.5, 4))
    ConfusionMatrixDisplay(cm, display_labels=CLASS_NAMES).plot(ax=ax, cmap="Blues", colorbar=False)
    ax.set_title("Confusion matrix (test set)")
    fig.tight_layout(); fig.savefig(out_dir / "confusion_matrix.png", dpi=130); plt.close(fig)

    ks = list(range(1, 16, 2))
    means, stds = [], []
    for k in ks:
        s = cross_val_score(make_pipeline(args.features, k), X_tr, y_tr, cv=cv)
        means.append(s.mean()); stds.append(s.std())
    means, stds = np.array(means), np.array(stds)
    fig, ax = plt.subplots(figsize=(5.5, 4))
    ax.plot(ks, means, marker="o"); ax.fill_between(ks, means - stds, means + stds, alpha=0.2)
    ax.set_xlabel("k (neighbours)"); ax.set_ylabel("CV accuracy"); ax.set_title("Choosing k")
    ax.set_ylim(0, 1.05); fig.tight_layout()
    fig.savefig(out_dir / "k_curve.png", dpi=130); plt.close(fig)

    counts = Counter(oils)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.barh(list(counts), list(counts.values()))
    ax.set_xlabel("Images"); ax.set_title("Dataset size per oil")
    fig.tight_layout(); fig.savefig(out_dir / "class_distribution.png", dpi=130); plt.close(fig)

    # ---- save ----
    joblib.dump({"model": model, "features": args.features}, ROOT / "models" / "knn_oil.joblib")
    metrics = {
        "features": args.features, "n_images": int(len(y)),
        "n_train": int(len(y_tr)), "n_test": int(len(y_te)),
        "test_accuracy": round(float(acc), 4),
        "cv_accuracy": round(float(grid.best_score_), 4),
        "best_params": grid.best_params_,
        "confusion_matrix": cm.tolist(), "report": report,
    }
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=2))
    print("\nSaved model to models/knn_oil.joblib and analytics to static/analytics/")


if __name__ == "__main__":
    main()
