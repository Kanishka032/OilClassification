"""Prediction helpers.  CLI:  python -m src.predict path/to/image.jpg"""
import sys
import joblib
from .features import CLASS_NAMES, decode_image, extract_features


def load_bundle(path):
    return joblib.load(path)


def predict_bytes(bundle, data: bytes):
    model, mode = bundle["model"], bundle["features"]
    x = extract_features(decode_image(data), mode).reshape(1, -1)
    proba = model.predict_proba(x)[0]
    idx = int(proba.argmax())
    return {
        "label": CLASS_NAMES[int(model.classes_[idx])],
        "confidence": round(float(proba[idx]) * 100, 1),
        "probabilities": {CLASS_NAMES[int(c)]: round(float(p) * 100, 1)
                          for c, p in zip(model.classes_, proba)},
    }


if __name__ == "__main__":
    from pathlib import Path
    bundle = load_bundle(Path(__file__).resolve().parent.parent / "models" / "knn_oil.joblib")
    print(predict_bytes(bundle, open(sys.argv[1], "rb").read()))
