"""Image loading, preprocessing and feature extraction (OpenCV)."""
from pathlib import Path
import cv2
import numpy as np

IMG_SIZE = (64, 64)                    # every image is resized to 64x64
CLASS_NAMES = ["edible", "non_edible"]  # label 0 / 1
IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def decode_image(data: bytes):
    """Bytes (from an upload) -> BGR image."""
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("File is not a readable image.")
    return img


def preprocess(img):
    """Resize + convert BGR (OpenCV default) to RGB, uint8 array (64, 64, 3)."""
    img = cv2.resize(img, IMG_SIZE, interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def pixel_features(img):
    """Flatten pixels into one vector: 64*64*3 = 12288 values in [0, 1]."""
    return preprocess(img).astype(np.float32).ravel() / 255.0


def rgb_stat_features(img):
    """Paper-style features: mean, max, min, mode, std for each of R, G, B (15 values)."""
    rgb = preprocess(img)
    feats = []
    for c in range(3):
        ch = rgb[:, :, c].ravel()
        mode = np.bincount(ch, minlength=256).argmax()
        feats += [ch.mean(), ch.max(), ch.min(), mode, ch.std()]
    return np.array(feats, dtype=np.float32) / 255.0


def extract_features(img, mode="pixels"):
    if mode == "pixels":
        return pixel_features(img)
    if mode == "stats":
        return rgb_stat_features(img)
    raise ValueError(f"Unknown feature mode: {mode}")


def load_dataset(root, mode="pixels"):
    """Read dataset/<edible|non_edible>/[oil_name/]*.jpg -> X, y, oil_names."""
    root = Path(root)
    X, y, oils = [], [], []
    for label, cls in enumerate(CLASS_NAMES):
        for path in sorted((root / cls).rglob("*")):
            if path.suffix.lower() not in IMG_EXT:
                continue
            img = cv2.imread(str(path))
            if img is None:
                print(f"Skipping unreadable file: {path}")
                continue
            X.append(extract_features(img, mode))
            y.append(label)
            rel = path.relative_to(root / cls)
            oils.append(rel.parts[0] if len(rel.parts) > 1 else cls)
    if not X:
        raise SystemExit(f"No images found under {root}/edible and {root}/non_edible")
    return np.array(X), np.array(y), np.array(oils)
