# Oil Image Classifier (Edible vs Non-edible) - KNN + Flask

Based on: Kolakoti & Chandramouli, "Prediction of significant oil properties using image
processing based on RGB pixel intensity", Fuel 349 (2023) 128618.

## Structure
```
oil-classifier/
├── app.py                  Flask backend (/, /predict, /analytics)
├── requirements.txt
├── src/
│   ├── features.py         OpenCV loading, resize, flatten, RGB-statistics features
│   ├── train.py            KNN + GridSearchCV, evaluation, analytics plots, saves model
│   └── predict.py          Prediction helper + command-line predictor
├── scripts/make_demo_data.py   SYNTHETIC images for testing only
├── dataset/
│   ├── edible/<oil_name>/*.jpg
│   └── non_edible/<oil_name>/*.jpg
├── models/                 knn_oil.joblib is created by training
├── static/                 style.css, analytics/ (plots + metrics.json)
└── templates/              index.html, analytics.html
```

## Run
```
pip install -r requirements.txt
# 1. Put your own photos in dataset/edible/<oil>/ and dataset/non_edible/<oil>/
#    (or run  python scripts/make_demo_data.py  to test the pipeline with fake data)
python -m src.train --features pixels      # flattened 64x64 pixels (as in your brief)
python -m src.train --features stats       # paper-style mean/max/min/mode/std of R,G,B
python app.py                              # open http://127.0.0.1:5000
python -m src.predict some_image.jpg       # optional command-line prediction
```

## Suggested dataset (assumed label mapping - state this in your report)
Edible: coconut, cottonseed, groundnut, olive, rice bran, soybean, sunflower.
Non-edible: algae, castor, jatropha, mahua, neem.
The paper does not label oils as edible/non-edible itself, and waste cooking oil is
ambiguous, so it is left out. Capture photos the way the paper does: fixed 100 ml volume,
same beaker, camera parallel to the surface, closed box with fixed lamps, no reflections.
