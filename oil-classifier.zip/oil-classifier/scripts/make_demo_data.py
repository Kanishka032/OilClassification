"""Create SYNTHETIC demo images (coloured noise) so you can test the pipeline end-to-end.
Mean RGB values come from Tables 2 and 5 of the paper. This is NOT real data:
replace it with photos of real oils before reporting any accuracy.
Run:  python scripts/make_demo_data.py
"""
from pathlib import Path
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
OILS = {  # (class, mean R, G, B)
    "coconut": ("edible", 160, 169, 148), "cottonseed": ("edible", 152, 166, 101),
    "groundnut": ("edible", 178, 166, 3), "olive": ("edible", 198, 171, 4),
    "ricebran": ("edible", 161, 179, 129), "soybean": ("edible", 157, 171, 96),
    "sunflower": ("edible", 173, 186, 161),
    "algae": ("non_edible", 134, 131, 4), "castor": ("non_edible", 198, 20, 4),
    "jatropha": ("non_edible", 209, 95, 4), "mahua": ("non_edible", 151, 128, 3),
    "neem": ("non_edible", 191, 159, 3),
}
rng = np.random.default_rng(0)
for oil, (cls, r, g, b) in OILS.items():
    d = ROOT / "dataset" / cls / oil
    d.mkdir(parents=True, exist_ok=True)
    for i in range(30):
        base = np.array([b, g, r], dtype=np.float32) + rng.normal(0, 8)      # BGR + lighting shift
        img = base + rng.normal(0, 12, (200, 200, 3))                        # texture noise
        cv2.imwrite(str(d / f"{oil}_{i:03d}.jpg"), np.clip(img, 0, 255).astype(np.uint8))
print("Demo images written to dataset/")
